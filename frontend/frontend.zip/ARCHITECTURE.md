# Архитектура проекта ЖКХ Помощник

## 📐 Системная архитектура

### Frontend (React + Vite)
```
┌─────────────────────────────────────┐
│   Browser / Frontend (React 18)     │
├─────────────────────────────────────┤
│  Components Layer                    │
│  ├── Navigation                      │
│  ├── ChatAssistant                   │
│  └── Footer                          │
├─────────────────────────────────────┤
│  Pages Layer                         │
│  ├── FAQ.jsx                         │
│  ├── News.jsx                        │
│  ├── Calculator.jsx                  │
│  ├── DocumentBuilder.jsx             │
│  ├── SelfCheck.jsx                   │
│  └── RegulationDocs.jsx              │
├─────────────────────────────────────┤
│  Styles Layer (CSS/CSS Modules)      │
│  └── global.css, pages.css, etc.     │
├─────────────────────────────────────┤
│  State Management (React Hooks)      │
│  ├── useState                        │
│  └── useEffect                       │
└─────────────────────────────────────┘
         ↓ (API calls)
┌─────────────────────────────────────┐
│   Backend API (Future)               │
│   - User Authentication              │
│   - Document Storage                 │
│   - AI Chat Integration              │
│   - News Management                  │
└─────────────────────────────────────┘
```

## 🏗️ Компонентная структура

### Иерархия компонентов
```
App.jsx (root)
├── Navigation
│   ├── nav-logo
│   ├── nav-links
│   └── nav-cta
├── Main Content (Pages)
│   ├── FAQ
│   │   ├── faq-categories
│   │   │   └── faq-items
│   │   └── faq-cta
│   ├── News
│   │   ├── news-filters
│   │   └── news-list
│   ├── Calculator
│   │   ├── calculator-form
│   │   └── calculator-result
│   ├── DocumentBuilder
│   │   ├── doc-selector
│   │   ├── doc-form
│   │   └── doc-preview
│   ├── SelfCheck
│   │   ├── check-nav
│   │   └── checklist
│   └── RegulationDocs
│       ├── regulation-groups
│       └── regulations-footer
├── ChatAssistant
│   ├── chat-float-btn
│   └── chat-window (when open)
│       ├── chat-messages
│       └── chat-input-area
└── Footer
    ├── footer-grid
    └── footer-bottom
```

## 🔄 Data Flow (Поток данных)

### FAQ
```
User clicks category
    ↓
toggleCategory() updates expandedCategory state
    ↓
Render filtered questions
    ↓
User clicks question
    ↓
toggleItem() updates expandedItems state
    ↓
Show answer
```

### Calculator
```
User fills form
    ↓
setFormData() updates state
    ↓
User clicks "Calculate"
    ↓
calculatePayment() processes data
    ↓
Show detailed breakdown
    ↓
User can download/print
```

### Document Builder
```
User selects document type
    ↓
setSelectedDoc() changes template
    ↓
User fills form fields
    ↓
setFormData() updates state
    ↓
Template re-renders with user data
    ↓
downloadPDF() exports document
```

### Chat Assistant
```
User opens chat
    ↓
setChatOpen(true)
    ↓
Chat window renders with history
    ↓
User types message
    ↓
handleSendMessage() adds to messages
    ↓
Simulate/fetch AI response
    ↓
Add bot message to state
    ↓
Auto-scroll to latest message
```

## 🎨 Стилизация

### CSS Переменные (в variables.css)
```css
:root {
  --navy: #0D1B35;        /* Основной темный цвет */
  --teal: #1D9E75;        /* Основной действующий цвет */
  --amber: #E8A020;       /* Предупреждение */
  --coral: #D85A30;       /* Критичное */
  --ink: #0D1B35;         /* Текст */
  --surface: #F7F8FC;     /* Фон */
  --radius: 16px;         /* Скругления */
  /* ... */
}
```

### CSS Организация
```
global.css        → Базовые стили, сброс, утилиты
variables.css     → CSS переменные
navigation.css    → Стили навигации
footer.css        → Стили footer
chat-assistant.css → Стили чата
pages.css         → Стили для всех страниц (FAQ, News, etc.)
```

### Медиа-запросы
```
Desktop (default)     → 1200px+ (2-3 колонки)
Tablet (1024px)       → 1-2 колонки, меньше отступы
Mobile (768px)        → 1 колонка, компактная навигация
Small phone (480px)   → Минимальные отступы, укороченный текст
```

## 📦 Зависимости

### Core
- **react** ^18.2.0 — UI библиотека
- **react-dom** ^18.2.0 — DOM rendering

### Dev
- **vite** ^4.4.0 — Build tool (вместо Create React App)
- **@vitejs/plugin-react** — React для Vite
- **TypeScript types** (опционально)

## 🔌 API Integration Points

### Где интегрировать backend

1. **ChatAssistant** (`components/ChatAssistant.jsx`)
```javascript
// Заменить setTimeout на:
const response = await fetch('/api/chat', {
  method: 'POST',
  body: JSON.stringify({ 
    message: input,
    conversationId: /* ... */
  })
});
```

2. **Calculator** (`pages/Calculator.jsx`)
```javascript
// Получать актуальные тарифы:
const tariffs = await fetch('/api/tariffs', {
  params: { region, date: new Date() }
});
```

3. **DocumentBuilder** (`pages/DocumentBuilder.jsx`)
```javascript
// Сохранение документа:
await fetch('/api/documents', {
  method: 'POST',
  body: JSON.stringify({ template, data })
});
```

4. **News** (`pages/News.jsx`)
```javascript
// Получение новостей:
const news = await fetch('/api/news?category=all&limit=10');
```

## 🗄️ State Management Strategy

### Текущий подход: React Hooks
Каждый компонент управляет своим локальным состоянием через useState.

### Будущие улучшения
Если состояние станет сложнее, рассмотрите:
- **Context API** для глобального состояния (Auth, theme)
- **Redux/Zustand** для более сложного state management
- **React Query** для асинхронных данных

Пример Context для авторизации:
```javascript
const AuthContext = React.createContext();

export function useAuth() {
  return useContext(AuthContext);
}
```

## 🔐 Готовность к backend

### Структура для API
```
/api
  /auth
    POST /login
    POST /logout
    POST /register
  /user
    GET /profile
    PUT /profile
  /documents
    GET /
    POST /
    GET /:id
    DELETE /:id
  /chat
    POST /message
  /news
    GET /
  /tariffs
    GET /
```

### Обработка ошибок
```javascript
try {
  const response = await fetch('/api/...');
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  const data = await response.json();
  // use data
} catch (error) {
  console.error('Error:', error);
  // Show user-friendly message
}
```

## 🧪 Testing Strategy

### Рекомендуемые инструменты
- **Vitest** — Unit testing
- **React Testing Library** — Component testing
- **Cypress/Playwright** — E2E testing

### Пример теста
```javascript
import { render, screen } from '@testing-library/react';
import FAQ from './pages/FAQ';

test('expands FAQ category on click', () => {
  render(<FAQ />);
  const categoryBtn = screen.getByText('Начисления и платежи');
  categoryBtn.click();
  expect(screen.getByText('Почему мне пришла огромная сумма')).toBeInTheDocument();
});
```

## 📊 Performance Optimization

### Текущее состояние
- ✅ CSS-in-JS для быстрого загрузку
- ✅ Минимальные зависимости
- ✅ Lazy loading для больших списков

### Будущие оптимизации
- React.lazy() для code splitting по страницам
- Memoization (React.memo, useMemo) для тяжелых компонентов
- Service Worker для offline поддержки
- Image optimization и WebP формат

## 🚀 Deployment

### Статический хостинг (Vercel, Netlify)
```bash
npm run build
# Загрузить папку 'dist' на хостинг
```

### Docker (будущий вариант)
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package.json .
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "run", "preview"]
```

### Environment Variables
```
VITE_API_URL=https://api.zhkh-pomoshnik.ru
VITE_AI_API_KEY=sk-...
VITE_REGION=kirov
```

## 🐛 Debugging Tips

### Browser DevTools
1. React DevTools — инспекция компонентов
2. Network tab — API calls
3. Console — ошибки и логи
4. Performance — оптимизация

### Common Issues
- **State не обновляется** → Проверьте функцию setState
- **Компонент не рендерится** → Проверьте conditional rendering
- **CSS не применяется** → Проверьте специфичность селекторов
- **API 404** → Проверьте endpoint URL и CORS

## 📚 Полезные ресурсы

### Documentation
- [React Docs](https://react.dev)
- [Vite Guide](https://vitejs.dev/guide/)
- [MDN CSS Reference](https://developer.mozilla.org/en-US/docs/Web/CSS)

### Best Practices
- [React Best Practices](https://react.dev/learn)
- [Web Components](https://web.dev/custom-elements-v1/)
- [Accessibility](https://www.a11y.me/)

## 📝 Git Workflow

### Ветви
```
main          → Production ready
develop       → Development branch
feature/*     → Новые функции
bugfix/*      → Исправления ошибок
```

### Commit messages
```
feat: Add new FAQ category
fix: Fix chat scrolling on mobile
docs: Update README
style: Format CSS
refactor: Simplify calculator logic
```

---

**Версия документации:** 1.0  
**Последнее обновление:** 24 марта 2026  
**Автор:** ЖКХ Помощник Development Team
