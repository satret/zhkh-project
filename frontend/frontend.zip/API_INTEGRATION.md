# API Integration Guide

## 📡 Примеры API интеграции для backend

### 1. Chat Assistant API

#### Frontend (ChatAssistant.jsx)
```javascript
const handleSendMessage = async () => {
  if (!input.trim()) return;

  const userMessage = {
    id: messages.length + 1,
    type: 'user',
    text: input
  };
  setMessages([...messages, userMessage]);
  setInput('');
  setLoading(true);

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        message: input,
        conversationId: conversationId,
        context: {
          page: 'faq', // или другая текущая страница
          region: userRegion
        }
      })
    });

    if (!response.ok) {
      throw new Error('API Error: ' + response.status);
    }

    const data = await response.json();
    
    const botMessage = {
      id: messages.length + 2,
      type: 'bot',
      text: data.response,
      sources: data.sources // Ссылки на законы
    };
    
    setMessages(prev => [...prev, botMessage]);
  } catch (error) {
    console.error('Error:', error);
    const errorMessage = {
      id: messages.length + 2,
      type: 'bot',
      text: 'Извините, произошла ошибка. Попробуйте позже.'
    };
    setMessages(prev => [...prev, errorMessage]);
  } finally {
    setLoading(false);
  }
};
```

#### Backend (Node.js/Express example)
```javascript
// routes/chat.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.post('/chat', authMiddleware, async (req, res) => {
  try {
    const { message, conversationId, context } = req.body;
    const userId = req.user.id;

    // Validate input
    if (!message || message.trim().length === 0) {
      return res.status(400).json({ error: 'Message is empty' });
    }

    // Get or create conversation
    let conversation = await Conversation.findById(conversationId);
    if (!conversation) {
      conversation = await Conversation.create({
        userId,
        messages: []
      });
    }

    // Save user message
    conversation.messages.push({
      role: 'user',
      content: message,
      timestamp: new Date()
    });

    // Call AI API (OpenAI, Claude, etc.)
    const aiResponse = await callAIAPI(message, context);

    // Save bot response
    conversation.messages.push({
      role: 'assistant',
      content: aiResponse.text,
      timestamp: new Date()
    });

    await conversation.save();

    return res.json({
      response: aiResponse.text,
      sources: aiResponse.sources,
      conversationId: conversation._id
    });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
```

---

### 2. Calculator Tariffs API

#### Frontend (Calculator.jsx)
```javascript
const loadTariffs = async (region) => {
  try {
    const response = await fetch(`/api/tariffs/${region}`);
    const data = await response.json();
    setTariffs(data);
  } catch (error) {
    console.error('Error loading tariffs:', error);
  }
};

const calculatePayment = async (e) => {
  e.preventDefault();
  
  try {
    const response = await fetch('/api/calculate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        region,
        squareMeters,
        hasCounters,
        waterUsage,
        electricityUsage
      })
    });

    const data = await response.json();
    setResult(data);
  } catch (error) {
    console.error('Calculation error:', error);
  }
};
```

#### Backend
```javascript
// routes/tariffs.js
router.get('/tariffs/:region', async (req, res) => {
  try {
    const { region } = req.params;
    
    const tariffs = await Tariff.findOne({ 
      region,
      date: { $gte: new Date(new Date().setFullYear(new Date().getFullYear())) }
    }).sort({ date: -1 });

    if (!tariffs) {
      return res.status(404).json({ error: 'Tariffs not found' });
    }

    res.json(tariffs.rates);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/calculate', async (req, res) => {
  try {
    const { region, squareMeters, hasCounters, waterUsage, electricityUsage } = req.body;

    // Get current tariffs
    const tariffs = await getTariffsByRegion(region);

    // Calculate using formula
    const calculations = calculatePayment({
      tariffs,
      squareMeters,
      hasCounters,
      waterUsage,
      electricityUsage
    });

    res.json({
      breakdown: calculations,
      total: calculations.total,
      timestamp: new Date()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

### 3. Document Builder API

#### Frontend (DocumentBuilder.jsx)
```javascript
const saveDocument = async () => {
  try {
    const response = await fetch('/api/documents', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        type: selectedDoc,
        content: documentTemplates[selectedDoc].template,
        formData,
        timestamp: new Date()
      })
    });

    const data = await response.json();
    alert(`Документ сохранён с ID: ${data.documentId}`);
  } catch (error) {
    console.error('Save error:', error);
  }
};

const generatePDF = async () => {
  try {
    const response = await fetch('/api/documents/generate-pdf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: selectedDoc,
        content: currentTemplate.template,
        formData
      })
    });

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentTemplate.title}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error('PDF generation error:', error);
  }
};
```

#### Backend
```javascript
// routes/documents.js
const PDFDocument = require('pdfkit');

router.post('/documents', authMiddleware, async (req, res) => {
  try {
    const { type, content, formData } = req.body;
    const userId = req.user.id;

    const document = await Document.create({
      userId,
      type,
      content,
      formData,
      status: 'draft',
      createdAt: new Date()
    });

    res.json({ documentId: document._id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/documents/generate-pdf', async (req, res) => {
  try {
    const { type, content, formData } = req.body;

    // Create PDF
    const doc = new PDFDocument();
    doc.fontSize(12);
    doc.text(content);

    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${type}.pdf"`);

    doc.pipe(res);
    doc.end();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

### 4. News API

#### Frontend (News.jsx)
```javascript
const [news, setNews] = useState([]);

useEffect(() => {
  const fetchNews = async () => {
    try {
      const response = await fetch(`/api/news?category=${selectedCategory}&limit=10`);
      const data = await response.json();
      setNews(data.news);
    } catch (error) {
      console.error('Error loading news:', error);
    }
  };

  fetchNews();
}, [selectedCategory]);
```

#### Backend
```javascript
// routes/news.js
router.get('/news', async (req, res) => {
  try {
    const { category, limit = 10, offset = 0 } = req.query;
    
    const query = category && category !== 'all' 
      ? { category } 
      : {};

    const news = await News.find(query)
      .sort({ importance: 1, date: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset));

    const total = await News.countDocuments(query);

    res.json({ news, total, hasMore: total > offset + limit });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

### 5. User Authentication API

#### Frontend
```javascript
// services/auth.js
export async function login(email, password) {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  const data = await response.json();
  
  if (!response.ok) {
    throw new Error(data.error);
  }

  // Store token
  localStorage.setItem('authToken', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));
  
  return data;
}

export function getAuthToken() {
  return localStorage.getItem('authToken');
}

export function logout() {
  localStorage.removeItem('authToken');
  localStorage.removeItem('user');
}
```

#### Backend
```javascript
// routes/auth.js
const jwt = require('jsonwebtoken');

router.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    // Check password
    const isValid = await user.comparePassword(password);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Generate JWT
    const token = jwt.sign(
      { id: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      token,
      user: { id: user._id, email: user.email, name: user.name }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

## 🗄️ Database Schema Examples

### MongoDB (с Mongoose)

```javascript
// models/Document.js
const documentSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  type: { type: String, required: true },
  title: String,
  content: String,
  formData: mongoose.Schema.Types.Mixed,
  status: { type: String, enum: ['draft', 'sent', 'completed'] },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// models/Conversation.js
const conversationSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  messages: [{
    role: { type: String, enum: ['user', 'assistant'] },
    content: String,
    timestamp: Date
  }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// models/News.js
const newsSchema = new mongoose.Schema({
  title: { type: String, required: true },
  excerpt: String,
  content: String,
  category: { type: String, required: true },
  importance: { type: String, enum: ['high', 'medium', 'low'] },
  image: String,
  date: { type: Date, default: Date.now },
  author: String,
  published: { type: Boolean, default: true }
});
```

---

## 🔐 Security Best Practices

### CORS Configuration
```javascript
const cors = require('cors');

app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
```

### Rate Limiting
```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use('/api/', limiter);
```

### Input Validation
```javascript
const { body, validationResult } = require('express-validator');

router.post('/documents', [
  body('type').notEmpty(),
  body('formData').isObject(),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  // Process request
});
```

---

## 🚀 Deployment Configuration

### Environment Variables (.env)
```
# Frontend
VITE_API_URL=https://api.zhkh-pomoshnik.ru
VITE_API_TIMEOUT=30000

# Backend
NODE_ENV=production
PORT=3000
DATABASE_URL=mongodb://...
JWT_SECRET=your-secret-key
CORS_ORIGIN=https://zhkh-pomoshnik.ru
AI_API_KEY=sk-...
AI_API_URL=https://api.openai.com/v1
```

### Docker Compose (Backend + Database)
```yaml
version: '3.8'
services:
  mongodb:
    image: mongo:latest
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    ports:
      - "27017:27017"

  backend:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=mongodb://admin:password@mongodb:27017
    depends_on:
      - mongodb
```

---

Обновляйте этот документ по мере добавления новых API endpoints.
