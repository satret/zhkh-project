# 🚀 Быстрый старт — ЖКХ Помощник

## 📋 Требования

- **Node.js**: 16.0.0 или выше (рекомендуется 18+)
- **npm**: 7.0.0 или выше (или yarn/pnpm)
- **Git** (опционально, для клонирования)

Проверьте версию:
```bash
node --version  # должно быть v16+ или v18+
npm --version   # должно быть 7+
```

## 📥 Установка

### Вариант 1: Через npm

1. **Перейдите в папку проекта:**
```bash
cd zhkh-assistant
```

2. **Установите зависимости:**
```bash
npm install
```

3. **Запустите dev сервер:**
```bash
npm run dev
```

✅ Приложение откроется на **http://localhost:3000**

### Вариант 2: Через yarn

```bash
cd zhkh-assistant
yarn install
yarn dev
```

### Вариант 3: Через pnpm

```bash
cd zhkh-assistant
pnpm install
pnpm dev
```

## 🏗️ Структура файлов

После установки вы должны увидеть эту структуру:

```
zhkh-assistant/
├── src/
│   ├── App.jsx              # Главный компонент
│   ├── main.jsx             # Входная точка
│   ├── components/          # Компоненты
│   │   ├── Navigation.jsx
│   │   ├── Footer.jsx
│   │   └── ChatAssistant.jsx
│   ├── pages/               # Страницы приложения
│   │   ├── FAQ.jsx
│   │   ├── News.jsx
│   │   ├── Calculator.jsx
│   │   ├── DocumentBuilder.jsx
│   │   ├── SelfCheck.jsx
│   │   └── RegulationDocs.jsx
│   └── styles/              # Стили
│       ├── global.css
│       ├── variables.css
│       ├── navigation.css
│       ├── footer.css
│       ├── chat-assistant.css
│       └── pages.css
├── index.html               # HTML шаблон
├── vite.config.js          # Конфигурация Vite
├── package.json            # Зависимости
├── README.md               # Документация
├── ARCHITECTURE.md         # Архитектура проекта
├── API_INTEGRATION.md      # Интеграция API
└── node_modules/           # Установленные пакеты (создаётся после npm install)
```

## 🔧 Команды

### Разработка

```bash
# Запуск dev сервера с горячей перезагрузкой
npm run dev

# Приложение доступно на http://localhost:3000
```

### Сборка для продакшена

```bash
# Создаёт оптимизированную версию в папке 'dist'
npm run build

# Размер должен быть 50-100 KB (gzipped)
```

### Предпросмотр сборки

```bash
# Показывает как будет выглядеть продакшн версия
npm run preview
```

### Линтинг (опционально)

```bash
# Проверка кода на ошибки
npm run lint
```

## 🎨 Первые шаги в разработке

### 1. Добавить новый вопрос в FAQ

Откройте `src/pages/FAQ.jsx` и найдите массив `categories`. Добавьте новый вопрос:

```javascript
{
  id: 'q32',
  q: 'Мой новый вопрос?',
  a: 'Ответ на вопрос...'
}
```

### 2. Изменить цвета

Откройте `src/styles/variables.css`:

```css
:root {
  --teal: #1D9E75;  /* Измените на нужный цвет */
  --navy: #0D1B35;
  /* ... остальные переменные */
}
```

### 3. Добавить новую страницу

1. Создайте новый файл `src/pages/MyPage.jsx`:
```javascript
import React from 'react';
import '../styles/pages.css';

export default function MyPage() {
  return (
    <section className="page-section">
      <div className="section-inner">
        <div className="page-header">
          <h1>Моя новая страница</h1>
        </div>
        {/* Контент */}
      </div>
    </section>
  );
}
```

2. Импортируйте в `src/App.jsx`:
```javascript
import MyPage from './pages/MyPage';
```

3. Добавьте в объект `pages`:
```javascript
const pages = {
  mypage: <MyPage />,
  // ... остальные
};
```

4. Добавьте ссылку в навигацию:
```javascript
const navItems = [
  { id: 'mypage', label: 'Моя страница' },
  // ... остальные
];
```

## 🐛 Решение проблем

### `npm install` зависает

```bash
# Очистите кэш npm
npm cache clean --force

# Установите заново
npm install
```

### Порт 3000 уже используется

Приложение автоматически выберет другой порт, или вы можете указать свой:

```bash
npm run dev -- --port 3001
```

### Изменения не применяются

```bash
# Перезагрузите страницу в браузере (Ctrl+Shift+R или Cmd+Shift+R)
# Или очистите кэш браузера
```

### Ошибка "Cannot find module"

```bash
# Удалите node_modules и переустановите
rm -rf node_modules package-lock.json
npm install
```

### На Windows используйте PowerShell или CMD:
```bash
rmdir /s /q node_modules
del package-lock.json
npm install
```

## 📱 Тестирование на мобильном

### Локально (в той же сети)

1. Узнайте ваш IP адрес:
```bash
# macOS/Linux
ifconfig | grep "inet"

# Windows (в PowerShell)
ipconfig
```

2. Откройте на мобильном:
```
http://YOUR_IP:3000
```

### Через ngrok (для тестирования с реальным девайсом)

```bash
npm install -g ngrok
ngrok http 3000
```

## 🎯 Что дальше?

### 1. Добавьте свои данные
- Редактируйте FAQ вопросы
- Добавляйте новости
- Создавайте свои документы

### 2. Интегрируйте backend
- Следуйте инструкциям в `API_INTEGRATION.md`
- Замените локальные данные на API вызовы
- Добавьте авторизацию

### 3. Развёртывание
- Посмотрите раздел "Deployment" в README.md
- Используйте Vercel, Netlify или собственный сервер

### 4. Улучшения UX
- Добавьте темную тему
- Реализуйте поиск по FAQ
- Сделайте оффлайн поддержку (PWA)

## 📚 Полезные ссылки

### Документация
- [React Документация](https://react.dev)
- [Vite Гайд](https://vitejs.dev)
- [MDN Web Docs](https://developer.mozilla.org)

### Наш проект
- [README.md](./README.md) — Полная документация
- [ARCHITECTURE.md](./ARCHITECTURE.md) — Архитектура проекта
- [API_INTEGRATION.md](./API_INTEGRATION.md) — Интеграция с backend

## 🆘 Помощь

Если возникли проблемы:

1. ✅ Проверьте, что установлена правильная версия Node.js
2. ✅ Очистите node_modules и переустановите
3. ✅ Посмотрите консоль браузера (F12) на наличие ошибок
4. ✅ Проверьте логи dev сервера в терминале

## 📞 Контактная информация

- **Email:** support@zhkh-pomoshnik.ru
- **Issues:** Создавайте issues в репозитории
- **Docs:** https://docs.zhkh-pomoshnik.ru

---

**Готовы начать?** Запустите эту команду:
```bash
npm install && npm run dev
```

Приложение откроется автоматически! 🎉

---

**Версия:** 1.0.0  
**Обновлено:** 24 марта 2026
